//
//  ViewController.swift
//  Ataya
//
//  Created by Maram on 24/11/2025.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

